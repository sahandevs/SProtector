﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports System.Text
Module Module1

    Sub Main()
        'Dim rnd = New Random()
        'Dim nextValue = rnd.Next(3)
        'MsgBox(nextValue)
        'Main()
    End Sub
    Public Function Decrypt() As String
        Return ""
    End Function

    Public Function DEncrypt(TheText As String) As String
        Dim text As String = ""
        Dim arg_12_0 As Integer = 1
        Dim num As Integer = Strings.Len(TheText)
        Dim num2 As Integer = arg_12_0
        ' The following expression was wrapped in a checked-statement
        While True
            Dim arg_48_0 As Integer = num2
            Dim num3 As Integer = num
            If arg_48_0 > num3 Then
                Exit While
            End If
            Dim str As String = Conversions.ToString(Strings.Chr(Strings.Asc(Strings.Mid(TheText, num2, 1)) - 2))
            text += str
            num2 += 1
        End While
        Return Strings.Trim(text)
    End Function
    Public Function CryptDecrypt2(s As String) As String
        Dim arg_0B_0 As Long = 1L
        Dim num As Long = CLng(Strings.Len(s))
        Dim num2 As Long = arg_0B_0
        ' The following expression was wrapped in a checked-statement
        Dim text As String
        While True
            Dim arg_3D_0 As Long = num2
            Dim num3 As Long = num
            If arg_3D_0 > num3 Then
                Exit While
            End If
            text += Conversions.ToString(Strings.Chr(Strings.Asc(Strings.Mid(s, CInt(num2), 1)) Xor 255))
            num2 += 1L
        End While
        Return text
    End Function
    Public Function CryptDecrypt(text As String) As String
        Dim text2 As String = ""
        Dim arg_12_0 As Integer = 0
        ' The following expression was wrapped in a checked-statement
        Dim num As Integer = text.Length - 1
        Dim num2 As Integer = arg_12_0
        While True
            Dim arg_EF_0 As Integer = num2
            Dim num3 As Integer = num
            If arg_EF_0 > num3 Then
                Exit While
            End If
            Dim c As Char = Convert.ToChar(text.Substring(num2, 1))
            Dim num4 As Integer = AscW(c)
            Dim num5 As Integer = num4 + 13
            Dim flag As Boolean = num4 <= 90 AndAlso num4 >= 65
            If flag Then
                Dim flag2 As Boolean = num5 > 90
                Dim value As Char
                If flag2 Then
                    Dim num6 As Integer = num5 - 90
                    value = Strings.ChrW(64 + num6)
                Else
                    value = Strings.ChrW(num5)
                End If
                text2 += Conversions.ToString(value)
            Else
                Dim flag2 As Boolean = num4 <= 122 AndAlso num4 >= 97
                If flag2 Then
                    flag = (num5 > 122)
                    Dim value As Char
                    If flag Then
                        Dim num6 As Integer = num5 - 122
                        value = Strings.ChrW(96 + num6)
                    Else
                        value = Strings.ChrW(num5)
                    End If
                    text2 += Conversions.ToString(value)
                Else
                    text2 += Conversions.ToString(c)
                End If
            End If
            num2 += 1
        End While
        Return text2
    End Function
    Private _bool0 As Boolean

    <DllImport("kernel32.dll", CharSet:=CharSet.Auto, SetLastError:=True)>
    Friend Function LoadLibrary(string0 As String) As IntPtr
    End Function

    <DllImport("kernel32.dll", CharSet:=CharSet.Ansi, EntryPoint:="GetProcAddress", ExactSpelling:=True)>
    Friend Function GetProcAddress_3(intptr0 As IntPtr, string0 As String) As Delegate2
    End Function

    <DllImport("kernel32.dll", ExactSpelling:=True)>
    Friend Function GetCurrentProcessId() As UInteger
    End Function

    <DllImport("kernel32.dll", ExactSpelling:=True)>
    Friend Function OpenProcess(uint2 As UInteger, int1 As Integer, uint3 As UInteger) As IntPtr
    End Function

    <DllImport("kernel32.dll", CharSet:=CharSet.Ansi, EntryPoint:="GetProcAddress", ExactSpelling:=True)>
    Friend Function GetProcAddress_2(intptr0 As IntPtr, string0 As String) As Delegate4
    End Function

    <DllImport("kernel32.dll", ExactSpelling:=True)>
    Friend Function CloseHandle(intptr0 As IntPtr) As Integer
    End Function

    <DllImport("kernel32.dll", CharSet:=CharSet.Ansi, EntryPoint:="GetProcAddress", ExactSpelling:=True)>
    Friend Function GetProcAddress_5(intptr0 As IntPtr, string0 As String) As Delegate6
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto)>
    Friend Function GetClassName(intptr0 As IntPtr, stringBuilder0 As StringBuilder, int1 As Integer) As Integer
    End Function

    Public Sub CheckDebuger()
        Try
            If Debugger.IsAttached Then
                Environment.[Exit](0)
            End If
            Dim intptr__1 = LoadLibrary("kernel32.dll")
            Dim procAddress = GetProcAddress_3(intptr__1, "IsDebuggerPresent")
            If procAddress IsNot Nothing AndAlso procAddress() <> 0 Then
                Environment.[Exit](0)
            End If
            Dim currentProcessId = GetCurrentProcessId()
            Dim intPtr__2 = OpenProcess(1024UI, 0, currentProcessId)
            If intPtr__2 <> IntPtr.Zero Then
                Try
                    Dim procAddress2 = GetProcAddress_2(intptr__1, "CheckRemoteDebuggerPresent")
                    If procAddress2 IsNot Nothing Then
                        Dim num = 0
                        If procAddress2(intPtr__2, num) <> 0 AndAlso num <> 0 Then
                            Environment.[Exit](0)
                        End If
                    End If
                Finally
                    CloseHandle(intPtr__2)
                End Try
            End If
            Dim flag = False
            Try
                CloseHandle(New IntPtr(305419896))
            Catch
                flag = True
            End Try
            If flag Then
                Environment.[Exit](0)
            End If
            Try
                Dim intptr2 = LoadLibrary("user32.dll")
                Dim procAddress3 = GetProcAddress_5(intptr2, "EnumWindows")
                If procAddress3 IsNot Nothing Then
                    _bool0 = False
                    procAddress3(AddressOf smethod_0, IntPtr.Zero)
                    If _bool0 Then
                        Environment.[Exit](0)
                    End If
                End If
                ' ignored
            Catch
            End Try
            ' ignored
        Catch
        End Try
    End Sub

    Friend Function smethod_1(intptr0 As IntPtr) As String
        Dim stringBuilder = New StringBuilder(260)
        GetClassName(intptr0, stringBuilder, stringBuilder.Capacity)
        Return stringBuilder.ToString()
    End Function

    Private Function smethod_0(intptr0 As IntPtr, intptr1 As IntPtr) As Integer
        Dim array As String() = {"OLLYDBG"}
        Dim strA = smethod_1(intptr0)
        Dim array2 = array
        For Each strB In array2
            If String.Compare(strA, strB, StringComparison.OrdinalIgnoreCase) = 0 Then
                _bool0 = True
                Return 0
            End If
        Next
        Return 1
    End Function


    Friend Delegate Function Delegate2() As Integer

    Friend Delegate Function Delegate4(hProcess As IntPtr, ByRef pbDebuggerPresent As Integer) As Integer

    Friend Delegate Function Delegate5(wnd As IntPtr, lParam As IntPtr) As Integer

    Friend Delegate Function Delegate6(lpEnumFunc As Delegate5, lParam As IntPtr) As Integer
End Module
